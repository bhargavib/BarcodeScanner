
#import "ZBarCodeReaderDelegate.h"

@implementation KonyZBarReader
@synthesize scannedBarCode;
@synthesize waitCondition;

- (id) init {
	if (self = [super init]) {
		scannedBarCode = nil;
		waitCondition = [[NSCondition alloc] init];
	}
	return self;
}

// ZBar Library integration - Babjee
+ (NSString*) zbarStartScan
{
	KonyZBarReader* readerDelegate = [[KonyZBarReader alloc] init];
	
    // ADD: present a barcode reader that scans from the camera feed
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
	
	reader.readerDelegate = readerDelegate;
	reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    ZBarImageScanner *scanner = reader.scanner;
    // TODO: (optional) additional reader configuration here
	
    // EXAMPLE: disable rarely used I2/5 to improve performance
    [scanner setSymbology: ZBAR_I25
				   config: ZBAR_CFG_ENABLE
					   to: 0];
	
    // present and release the controller
    UINavigationController* navigationController = [[[[[[[UIApplication sharedApplication] keyWindow] subviews] objectAtIndex:0] subviews] objectAtIndex:0] delegate];
	
	[navigationController performSelectorOnMainThread:@selector(presentModalViewController:animated:) withObject:reader waitUntilDone:NO];
	
	
	
	[readerDelegate.waitCondition lock];
	[readerDelegate.waitCondition wait];
	[readerDelegate.waitCondition unlock];
	
	id result = [readerDelegate.scannedBarCode retain];
	//[readerDelegate release];
	
	[reader release];
	
	return result?result:nil;
}


// Delegate methods for UIImagePickerController
- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    // ADD: get the decode results
    id<NSFastEnumeration> results =
	[info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        // EXAMPLE: just grab the first barcode
        break;
	
    NSLog(@"Scanned barcode: %@",symbol.data);
	scannedBarCode = [symbol.data copyWithZone:NULL];
	
    // EXAMPLE: do something useful with the barcode image
    //resultImage.image =
	//[info objectForKey: UIImagePickerControllerOriginalImage];
	
    // ADD: dismiss the controller (NB dismiss from the *reader*!)
    [reader dismissModalViewControllerAnimated: YES];
	[waitCondition signal];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
	[picker dismissModalViewControllerAnimated:YES];
	[waitCondition signal];
}

// called when no barcode is found in an image selected by the user.
// if retry is NO, the delegate *must* dismiss the controller
- (void) readerControllerDidFailToRead: (ZBarReaderController*) reader
                             withRetry: (BOOL) retry {
	if (!retry) {
		[reader dismissModalViewControllerAnimated:YES];
		[waitCondition signal];
	}
}

- (void) dealloc {
	if(scannedBarCode) [scannedBarCode release];
	if(waitCondition) [waitCondition release];
	[super dealloc];
}

@end
