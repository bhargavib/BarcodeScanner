#import <UIKit/UIKit.h>
#import  "ZBarSDK.h"

@interface KonyZBarReader : NSObject <ZBarReaderDelegate>
{
	NSString *scannedBarCode;
	NSCondition *waitCondition;
}
@property (nonatomic,retain) NSString *scannedBarCode;
@property (nonatomic,retain) NSCondition *waitCondition;

@end
